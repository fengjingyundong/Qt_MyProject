/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_textEdit_copyAvailable",
    "",
    "b",
    "on_textEdit_selectionChanged",
    "on_actFont_Bold_triggered",
    "checked",
    "on_actFont_Italic_triggered",
    "on_actFont_UnderLine_triggered",
    "on_actSys_ToggleText_triggered",
    "on_actFile_New_triggered",
    "on_actFile_Open_triggered",
    "on_actFile_Save_triggered",
    "on_actLang_CN_triggered",
    "on_actLang_EN_triggered"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[30];
    char stringdata0[11];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[2];
    char stringdata4[29];
    char stringdata5[26];
    char stringdata6[8];
    char stringdata7[28];
    char stringdata8[31];
    char stringdata9[31];
    char stringdata10[25];
    char stringdata11[26];
    char stringdata12[26];
    char stringdata13[24];
    char stringdata14[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 25),  // "on_textEdit_copyAvailable"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 1),  // "b"
        QT_MOC_LITERAL(40, 28),  // "on_textEdit_selectionChanged"
        QT_MOC_LITERAL(69, 25),  // "on_actFont_Bold_triggered"
        QT_MOC_LITERAL(95, 7),  // "checked"
        QT_MOC_LITERAL(103, 27),  // "on_actFont_Italic_triggered"
        QT_MOC_LITERAL(131, 30),  // "on_actFont_UnderLine_triggered"
        QT_MOC_LITERAL(162, 30),  // "on_actSys_ToggleText_triggered"
        QT_MOC_LITERAL(193, 24),  // "on_actFile_New_triggered"
        QT_MOC_LITERAL(218, 25),  // "on_actFile_Open_triggered"
        QT_MOC_LITERAL(244, 25),  // "on_actFile_Save_triggered"
        QT_MOC_LITERAL(270, 23),  // "on_actLang_CN_triggered"
        QT_MOC_LITERAL(294, 23)   // "on_actLang_EN_triggered"
    },
    "MainWindow",
    "on_textEdit_copyAvailable",
    "",
    "b",
    "on_textEdit_selectionChanged",
    "on_actFont_Bold_triggered",
    "checked",
    "on_actFont_Italic_triggered",
    "on_actFont_UnderLine_triggered",
    "on_actSys_ToggleText_triggered",
    "on_actFile_New_triggered",
    "on_actFile_Open_triggered",
    "on_actFile_Save_triggered",
    "on_actLang_CN_triggered",
    "on_actLang_EN_triggered"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   80,    2, 0x08,    1 /* Private */,
       4,    0,   83,    2, 0x08,    3 /* Private */,
       5,    1,   84,    2, 0x08,    4 /* Private */,
       7,    1,   87,    2, 0x08,    6 /* Private */,
       8,    1,   90,    2, 0x08,    8 /* Private */,
       9,    1,   93,    2, 0x08,   10 /* Private */,
      10,    0,   96,    2, 0x08,   12 /* Private */,
      11,    0,   97,    2, 0x08,   13 /* Private */,
      12,    0,   98,    2, 0x08,   14 /* Private */,
      13,    0,   99,    2, 0x08,   15 /* Private */,
      14,    0,  100,    2, 0x08,   16 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_textEdit_copyAvailable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_textEdit_selectionChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actFont_Bold_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_actFont_Italic_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_actFont_UnderLine_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_actSys_ToggleText_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_actFile_New_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actFile_Open_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actFile_Save_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actLang_CN_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actLang_EN_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_textEdit_copyAvailable((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->on_textEdit_selectionChanged(); break;
        case 2: _t->on_actFont_Bold_triggered((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 3: _t->on_actFont_Italic_triggered((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 4: _t->on_actFont_UnderLine_triggered((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 5: _t->on_actSys_ToggleText_triggered((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 6: _t->on_actFile_New_triggered(); break;
        case 7: _t->on_actFile_Open_triggered(); break;
        case 8: _t->on_actFile_Save_triggered(); break;
        case 9: _t->on_actLang_CN_triggered(); break;
        case 10: _t->on_actLang_EN_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
